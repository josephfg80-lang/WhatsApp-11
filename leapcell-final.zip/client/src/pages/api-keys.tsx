import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Loader2, Plus, Copy, Trash2, Key, CheckCircle2, AlertCircle } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ApiKey {
  id: string;
  name: string;
  keyPreview: string;
  isActive: boolean;
  createdAt: string;
  lastUsedAt: string | null;
}

export default function ApiKeys() {
  const [keyName, setKeyName] = useState("");
  const [customKey, setCustomKey] = useState("");
  const [useCustomKey, setUseCustomKey] = useState(false);
  const [showNewKeyDialog, setShowNewKeyDialog] = useState(false);
  const [newKeyValue, setNewKeyValue] = useState("");
  const { toast } = useToast();

  const { data: keysData, isLoading } = useQuery<{ success: boolean; keys: ApiKey[] }>({
    queryKey: ["/api/keys"],
  });

  const createKeyMutation = useMutation({
    mutationFn: async (data: { name: string; customKey?: string }) => {
      return await apiRequest("POST", "/api/keys", data);
    },
    onSuccess: (data: any) => {
      setNewKeyValue(data.apiKey.key);
      setShowNewKeyDialog(true);
      setKeyName("");
      queryClient.invalidateQueries({ queryKey: ["/api/keys"] });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to create API key",
      });
    },
  });

  const toggleKeyMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) => {
      return await apiRequest("PATCH", `/api/keys/${id}`, { isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/keys"] });
      toast({
        title: "Success",
        description: "API key status updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to update API key",
      });
    },
  });

  const deleteKeyMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/keys/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/keys"] });
      toast({
        title: "Success",
        description: "API key deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to delete API key",
      });
    },
  });

  const handleCreateKey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!keyName.trim()) return;
    
    const data: { name: string; customKey?: string } = { name: keyName };
    if (useCustomKey && customKey.trim()) {
      data.customKey = customKey.trim();
    }
    
    createKeyMutation.mutate(data);
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: "API key copied to clipboard",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to copy to clipboard",
      });
    }
  };

  const keys = keysData?.keys || [];

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">API Keys</h1>
          <p className="text-muted-foreground mt-2">
            Manage your API keys to integrate WhatsApp messaging into your applications
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>إنشاء API Key جديد</CardTitle>
            <CardDescription>
              أنشئ مفتاح API جديد للمصادقة على طلبات API الخاصة بك
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreateKey} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="key-name">
                  اسم المفتاح
                </Label>
                <Input
                  id="key-name"
                  placeholder="مثلاً: سيرفر الإنتاج، تطبيق الموبايل، إلخ"
                  value={keyName}
                  onChange={(e) => setKeyName(e.target.value)}
                  data-testid="input-key-name"
                />
              </div>

              <div className="flex items-center gap-2">
                <Switch
                  id="use-custom-key"
                  checked={useCustomKey}
                  onCheckedChange={setUseCustomKey}
                  data-testid="switch-custom-key"
                />
                <Label htmlFor="use-custom-key" className="cursor-pointer">
                  استخدام رمز مخصص بدلاً من التوليد التلقائي
                </Label>
              </div>

              {useCustomKey && (
                <div className="space-y-2">
                  <Label htmlFor="custom-key">
                    الرمز المخصص
                  </Label>
                  <Input
                    id="custom-key"
                    placeholder="أدخل الرمز المخصص (مثلاً: wapi_myCustomKey123)"
                    value={customKey}
                    onChange={(e) => setCustomKey(e.target.value)}
                    data-testid="input-custom-key"
                  />
                  <p className="text-xs text-muted-foreground">
                    سيتم إضافة البادئة wapi_ تلقائياً إذا لم تكن موجودة
                  </p>
                </div>
              )}

              <Button
                type="submit"
                disabled={!keyName.trim() || createKeyMutation.isPending}
                className="w-full"
                data-testid="button-create-key"
              >
                {createKeyMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    جاري الإنشاء...
                  </>
                ) : (
                  <>
                    <Plus className="mr-2 h-4 w-4" />
                    إنشاء المفتاح
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>مفاتيح API الخاصة بك</CardTitle>
            <CardDescription>
              {keys.length === 0
                ? "لم تقم بإنشاء أي مفاتيح API بعد"
                : `إدارة ${keys.length} مفتاح${keys.length > 1 ? "" : ""} API`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : keys.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Key className="mx-auto h-12 w-12 mb-4 opacity-50" />
                <p>لا توجد مفاتيح API</p>
                <p className="text-sm">أنشئ أول مفتاح API للبدء</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>الاسم</TableHead>
                    <TableHead>المفتاح</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>تاريخ الإنشاء</TableHead>
                    <TableHead>آخر استخدام</TableHead>
                    <TableHead className="text-right">الإجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {keys.map((key) => (
                    <TableRow key={key.id} data-testid={`row-key-${key.id}`}>
                      <TableCell className="font-medium">{key.name}</TableCell>
                      <TableCell>
                        <code className="text-xs bg-muted px-2 py-1 rounded">
                          {key.keyPreview}
                        </code>
                      </TableCell>
                      <TableCell>
                        <Badge variant={key.isActive ? "default" : "secondary"}>
                          {key.isActive ? "نشط" : "معطل"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {new Date(key.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {key.lastUsedAt
                          ? new Date(key.lastUsedAt).toLocaleDateString('ar-EG')
                          : "لم يُستخدم بعد"}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Switch
                            checked={key.isActive}
                            onCheckedChange={(checked) =>
                              toggleKeyMutation.mutate({ id: key.id, isActive: checked })
                            }
                            data-testid={`switch-toggle-${key.id}`}
                          />
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteKeyMutation.mutate(key.id)}
                            data-testid={`button-delete-${key.id}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={showNewKeyDialog} onOpenChange={setShowNewKeyDialog}>
        <DialogContent data-testid="dialog-new-key">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-primary" />
              تم إنشاء API Key بنجاح
            </DialogTitle>
            <DialogDescription>
              احفظ هذا المفتاح بشكل آمن. لن تتمكن من رؤيته مرة أخرى!
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Alert className="border-yellow-500/50 bg-yellow-500/5">
              <AlertCircle className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-600 font-medium">
                ⚠️ انسخ هذا المفتاح الآن! هذه هي المرة الوحيدة التي ستتمكن فيها من رؤية المفتاح الكامل. لن يظهر مرة أخرى لأسباب أمنية.
              </AlertDescription>
            </Alert>
            <div className="space-y-3">
              <Label className="text-base font-semibold">مفتاح API الكامل</Label>
              <div className="flex gap-2">
                <Input
                  value={newKeyValue}
                  readOnly
                  className="font-mono text-sm bg-muted"
                  data-testid="input-new-key-value"
                />
                <Button
                  onClick={() => copyToClipboard(newKeyValue)}
                  variant="default"
                  size="lg"
                  data-testid="button-copy-key"
                  className="gap-2"
                >
                  <Copy className="h-4 w-4" />
                  نسخ المفتاح
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                💡 نصيحة: احفظ هذا المفتاح في مكان آمن (مثل مدير كلمات المرور)
              </p>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button
              onClick={() => copyToClipboard(newKeyValue)}
              variant="outline"
              size="lg"
              className="flex-1"
              data-testid="button-copy-again"
            >
              <Copy className="h-4 w-4 mr-2" />
              نسخ مرة أخرى
            </Button>
            <Button
              onClick={() => {
                setShowNewKeyDialog(false);
                setNewKeyValue("");
                setKeyName("");
                setCustomKey("");
                setUseCustomKey(false);
              }}
              size="lg"
              className="flex-1"
              data-testid="button-close-dialog"
            >
              <CheckCircle2 className="h-4 w-4 mr-2" />
              تم الحفظ، إغلاق
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
