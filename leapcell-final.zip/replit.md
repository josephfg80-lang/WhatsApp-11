# WhatsApp Message Sender

## Overview
A completely free WhatsApp messaging system that runs on Replit. Send WhatsApp messages through a web interface without any paid services or official Meta APIs. Uses whatsapp-web.js for WhatsApp Web protocol integration.

## Features
- **QR Code Authentication**: Scan once to link your WhatsApp account
- **Session Persistence**: Auto-reconnects on restart (no need to re-scan QR code)
- **CSV Bulk Sending**: Upload CSV files and send messages to multiple contacts sequentially
- **Real-time Progress Tracking**: Live countdown and remaining message counter
- **Web Interface**: Simple, clean form to send messages via browser
- **Free & Local**: No paid APIs, no external services, 100% self-hosted
- **REST API**: `/api/send` endpoint for programmatic message sending
- **API Key Management**: Persistent API keys with file-based storage
- **Visitor Tracking**: Automatic logging of server visits every 3 minutes

## Architecture

### Backend (Node.js + Express)
- **server/whatsapp.ts**: WhatsApp Web client with session management
  - Initializes client with LocalAuth strategy for session persistence
  - Handles QR code generation and authentication events
  - Provides sendMessage() function for message delivery
  - Validates phone numbers are registered on WhatsApp

- **server/routes.ts**: API endpoints
  - `GET /api/status` - Returns connection status and QR code data
  - `POST /api/send` - Sends WhatsApp message with validation

### Frontend (React + TypeScript)
- **client/src/pages/home.tsx**: Main messaging interface
  - Polls `/api/status` every 2 seconds for connection updates
  - Displays QR code when authentication is needed
  - Form with phone number and message inputs
  - Real-time feedback on message sending success/failure

- **client/src/pages/bulk-send.tsx**: CSV bulk messaging interface
  - CSV file upload with validation
  - Parses CSV with Arabic column headers (رقم الهاتف, الرساله الخاصه بالرقم)
  - Sequential message sending with 2.5 second delays via WhatsApp API
  - Real-time progress tracking with countdown timer
  - Displays remaining messages and estimated time in MM:SS format
  - Success/failure counters for sent messages
  - API Key authentication required
  - Auto-resume capability after server restart

### Data Persistence
- **WhatsApp Sessions**: Saved in `.wwebjs_auth/` directory
  - Automatically restores WhatsApp connection on server restart
  - No need to scan QR code again after first setup

- **API Keys**: Stored in `.storage/api_keys.json`
  - Persist across server restarts
  - No database required - file-based storage
  - Includes creation time and last usage tracking

- **Bulk Send Progress**: Stored in `.storage/bulk_send_progress.json`
  - Tracks current sending progress
  - Auto-resumes from last position after server restart
  - Clears automatically when sending completes

## How It Works

1. **First Run**: Server starts and displays QR code in console
2. **Scan QR**: Open WhatsApp mobile → Settings → Linked Devices → Link a Device
3. **Session Saved**: Authentication data saved locally for future use
4. **Send Messages**: Use web interface to send messages instantly
5. **Auto-Reconnect**: On server restart, session automatically restores

## API Usage

### Check Status
```bash
GET /api/status
```

Response:
```json
{
  "ready": true,
  "qrCode": null,
  "message": "WhatsApp is connected and ready to send messages"
}
```

### Send Message
```bash
POST /api/send
Content-Type: application/json

{
  "number": "201234567890",
  "message": "Hello from my free WhatsApp API"
}
```

Response:
```json
{
  "success": true,
  "message": "Message sent successfully!",
  "messageId": "..."
}
```

## Phone Number Format
- Include country code (e.g., +1 for US, +44 for UK, +91 for India)
- Remove spaces, dashes, parentheses (they're automatically cleaned)
- Examples: `+12345678901`, `12345678901`, `+919876543210`

## Technology Stack
- **Backend**: Node.js, Express, TypeScript
- **WhatsApp Client**: whatsapp-web.js (uses Puppeteer for WhatsApp Web automation)
- **Frontend**: React, TanStack Query, Tailwind CSS, shadcn/ui
- **QR Code**: qrcode library for visual display
- **Session Storage**: LocalAuth strategy with file-based persistence

## Recent Changes

### November 25, 2025 - CSV Upload Fix & Manual Progress Restore
- **Fixed**: CSV file upload issue where file selection appeared disabled
  - Removed automatic server check on page load that caused connection issues
  - File input now works reliably without server delays or interruptions
- **Changed**: Progress restore is now manual and opt-in
  - Removed automatic progress restore that triggered on page load
  - Added "استعادة التقدم المحفوظ" button for manual progress recovery
  - Button only appears when no files are loaded
  - Clear success/error messaging for restore operations
- **Improved**: User experience
  - No more automatic server calls blocking file selection
  - Added cursor pointer styling to file input for better UX
  - Clearer error messages when progress restore fails

### November 9, 2025 - Major Bulk Send API Integration & Keep-Alive System
- **Redesigned**: Bulk Send now uses WhatsApp API directly instead of opening browser tabs
  - Messages sent via `/api/send` endpoint with API Key authentication
  - No more opening multiple WhatsApp Web tabs
  - Direct backend message sending for reliability
  - Real-time success/failure counters for each message
  - Arabic interface for better user experience
- **Added**: Progress persistence and auto-resume
  - Bulk send progress saved to `.storage/bulk_send_progress.json`
  - Automatically resumes from last position after server restart
  - No messages lost even if server restarts during sending
  - Progress tracking includes current index, tasks, and API key
- **Added**: Keep-alive system
  - Automatically visits server every 3 minutes
  - Sends WhatsApp message to configured number (default: 01201819127)
  - Keeps Replit server alive and prevents sleep
  - Configurable phone number via localStorage
  - Integrated directly in App.tsx for reliability
- **Enhanced**: API endpoints
  - `POST /api/bulk-send/start` - Start bulk sending session
  - `GET /api/bulk-send/progress` - Get current progress
  - `POST /api/bulk-send/update-progress` - Update progress
  - `POST /api/bulk-send/complete` - Complete and clear session
- **Fixed**: API keys now properly persist across restarts
  - File-based storage in `.storage/api_keys.json`
  - Automatic initialization on server start
  - No more lost API keys after restart

### November 8, 2025 - CSV Bulk Messaging & Persistence Improvements
- **Added**: CSV bulk messaging feature
  - Upload CSV files with phone numbers and messages
  - Sequential sending with 2.5 second delays between messages
  - Real-time progress tracking with countdown timer
  - Support for Arabic CSV headers (رقم الهاتف, الرساله الخاصه بالرقم)
- **Added**: Visitor tracking functionality
  - Logs server visits every 3 minutes
  - Automatic tracking on page load
  - Console logging with IP address and timestamp
- **Updated**: Navigation with new "Bulk Send" page in sidebar

### November 6, 2025 - Bug Fix: Message Sending Error
- **Fixed**: "Evaluation failed: b" error when sending messages
- **Root Cause**: The `isRegisteredUser()` check was causing Puppeteer evaluation failures
- **Solution**: Removed unreliable phone number validation and improved error handling
- **Impact**: Messages now send successfully; clearer error messages for invalid numbers
- Improved phone number formatting and cleaning logic
- Added better logging for debugging message delivery issues

### November 6, 2025 - Initial Implementation
- Complete WhatsApp Web integration with session persistence
- REST API for sending messages (`/api/send`, `/api/status`)
- Clean, responsive web interface with React + shadcn/ui
- Real-time status polling and QR code display
- Session persistence using LocalAuth strategy

## Development
```bash
npm run dev    # Start development server
npm run build  # Build for production
npm run start  # Run production build
```

## Important Notes

### Message Sending
- **Use Real Phone Numbers**: The number must be registered on WhatsApp
- **Format**: Include country code (e.g., +201234567890 for Egypt, +12345678901 for US)
- **Testing**: Use your own phone number or a friend's number for testing
- **Error Messages**: If you see "not registered on WhatsApp", verify the number format and WhatsApp registration

### Rate Limits & Safety
- WhatsApp may ban accounts that send too many messages too quickly
- Recommended to use with personal WhatsApp accounts only
- Use responsibly - don't spam or send unsolicited messages
- Session files are critical - do not delete `.wwebjs_auth/` directory

### Troubleshooting
- **QR Code Issues**: QR code expires after ~60 seconds - refresh page if needed
- **Connection Lost**: Server restart will auto-reconnect using saved session
- **Message Fails**: Check that phone number includes country code and is WhatsApp-registered
